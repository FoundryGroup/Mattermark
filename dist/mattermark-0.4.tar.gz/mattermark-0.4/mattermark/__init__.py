################################################################################
# Python package __init__.py file.
#
# Author: Carl Cortright
# Date: 1/16/2017
#
################################################################################

from mattermark import mattermark.mattermark
